document.addEventListener('DOMContentLoaded', () => {
    const productList = document.getElementById('products-list');
    const compareButton = document.getElementById('compare-btn');

    function renderProducts(products) {
        productList.innerHTML = '';
        products.forEach((product, index) => {
            const productDiv = document.createElement('div');
            productDiv.textContent = product.title;

            const removeButton = document.createElement('button');
            removeButton.textContent = 'Remove';
            removeButton.style.marginLeft = '10px';
            removeButton.addEventListener('click', () => {
                removeProduct(index);
            });

            productDiv.appendChild(removeButton);
            productList.appendChild(productDiv);
        });
    }

    function removeProduct(index) {
        chrome.storage.local.get(['products'], function(result) {
            const products = result.products || [];
            products.splice(index, 1);
            chrome.storage.local.set({ products }, () => {
                renderProducts(products);
            });
        });
    }

    chrome.storage.local.get(['products'], function(result) {
        const products = result.products || [];
        renderProducts(products);
    });

    compareButton.addEventListener('click', () => {
        console.log('Compare button clicked');
        chrome.runtime.sendMessage({ action: 'compareProducts' }, (response) => {
            console.log('Received response from background:', response);
            if (response && response.data) {
                chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                    chrome.tabs.sendMessage(tabs[0].id, { action: 'showComparison', data: response.data }, (response) => {
                        console.log('Message sent to content script:', response);
                    });
                });
            }
        });
    });
});
