console.log('Content script loaded');

let checked = false;

const getAllReviews = async () => {
    let reviews = [];
    let hasNextPage = true;
    let pageNumber = 1;

    while (hasNextPage) {
        // Wait for reviews to load
        await new Promise(resolve => setTimeout(resolve, 3000));

        // Select the review elements
        const reviewElements = document.querySelectorAll('.mod-reviews .item .content');

        if (reviewElements.length === 0) {
            console.warn(`No reviews found on page ${pageNumber}`);
        } else {
            const pageReviews = [];
            reviewElements.forEach(review => pageReviews.push(review.textContent.trim()));
            reviews.push(...pageReviews);

            console.log(`Reviews from page ${pageNumber}:`, pageReviews);
        }

        // Check for next page button
        const nextPageButton = document.querySelector('button.ant-pagination-item-link[aria-label="right"]');
        if (nextPageButton && !nextPageButton.disabled) {
            console.log('Next page button found, clicking to load more reviews...');
            nextPageButton.click();
            pageNumber++;
        } else {
            console.log('No more pages found, stopping review collection.');
            hasNextPage = false;
        }
    }
    return reviews;
}

const checkElements = async () => {
    if (checked) return;

    const productTitle = document.querySelector('.pdp-mod-product-badge-title');
    const productPrice = document.querySelector('.pdp-price.pdp-price_type_normal.pdp-price_color_orange.pdp-price_size_xl');

    if (productTitle && productPrice) {
        console.log('Product Title:', productTitle.textContent.trim());
        console.log('Product Price:', productPrice.textContent.trim());

        const reviews = await getAllReviews();
        console.log('Collected Reviews:', reviews);

        if (reviews.length === 0) {
            console.log('No reviews found for this product.');
            return;
        }

        const productInfo = {
            title: productTitle.textContent.trim(),
            price: productPrice.textContent.trim(),
            url: window.location.href,
            reviews: reviews
        };

        console.log('Product Info being sent:', productInfo);

        const addToCompareButton = document.createElement('button');
        addToCompareButton.textContent = 'Add to Compare';
        addToCompareButton.style.backgroundColor = '#f0c14b';
        addToCompareButton.style.border = '1px solid #a88734';
        addToCompareButton.style.padding = '10px';
        addToCompareButton.style.cursor = 'pointer';
        addToCompareButton.style.marginTop = '10px';

        addToCompareButton.addEventListener('click', () => {
            // Save to local storage
            chrome.storage.local.get(['products'], function(result) {
                let products = result.products || [];
                if (!products.some(product => product.url === productInfo.url)) {
                    products.push(productInfo);
                    chrome.storage.local.set({ products }, () => {
                        console.log('Product added to local storage:', productInfo);
                        alert('Product added for comparison.');

                        // Send message to background script
                        chrome.runtime.sendMessage({ action: 'addProduct', product: productInfo });
                    });
                } else {
                    alert('Product already added for comparison.');
                }
            });
        });

        if (!document.querySelector('.add-to-compare-button')) {
            productTitle.parentNode.appendChild(addToCompareButton);
            addToCompareButton.className = 'add-to-compare-button';
        }

        checked = true;
    } else {
        console.log('Product title or price not found.');
    }
};

checkElements();

const observer = new MutationObserver(() => {
    setTimeout(() => {
        checked = false;
        checkElements();
    }, 1000);
});

observer.observe(document.body, {
    childList: true,
    subtree: true
});

// Handle incoming messages to display the modal
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'showComparison') {
        console.log('Received showComparison message:', request.data);
        showComparisonResult(request.data);
        sendResponse({ status: 'success' });
    }
});

function showComparisonResult(data) {
    // Remove existing modal if any
    const existingModal = document.getElementById('comparison-modal');
    if (existingModal) {
        existingModal.remove();
    }

    // Create a new modal
    const modal = document.createElement('div');
    modal.id = 'comparison-modal';
    modal.classList.add('modal');
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close-btn">&times;</span>
            <div id="comparison-result"></div>
        </div>
    `;
    document.body.appendChild(modal);

    const closeBtn = modal.getElementsByClassName('close-btn')[0];
    closeBtn.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });

    try {
        const { comparison_result, comparison_data, title1, title2 } = data;

        let comparisonHtml = `<h1>Comparison Result</h1>
                                <br>
                               <h2>Product 1:</h2><h3>${title1}</h3>
                               <br>
                               <h2>Product 2:</h2><h3>${title2}</h3>
                               <table>
                                   <tr><th>Metric</th><th>Product 1</th><th>Product 2</th></tr>`;
        comparison_data.Metric.forEach((metric, index) => {
            comparisonHtml += `<tr>
                                   <td>${metric}</td>
                                   <td>${comparison_data['Product 1'][index]}</td>
                                   <td>${comparison_data['Product 2'][index]}</td>
                               </tr>`;
        });
        comparisonHtml += '</table><br>';
        comparisonHtml += `<p><b>Result:</b> ${comparison_result.replace(/Product 1/g, '<b>Product 1</b>').replace(/Product 2/g, '<b>Product 2</b>').replace(/\n/g, '<br>')}</p>`;

        document.getElementById('comparison-result').innerHTML = comparisonHtml;
        modal.style.display = 'block';
    } catch (e) {
        console.error('Error parsing comparison data:', e);
        document.getElementById('comparison-result').textContent = 'Failed to load comparison data.';
    }
}

// Add styles for the modal
const style = document.createElement('style');
style.innerHTML = `
.modal {
    display: none; 
    position: fixed; 
    z-index: 1000; 
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    width: 100%; 
    max-width: 850px; 
    max-height: 90%;
    overflow-y: auto; 
    overflow-x: hidden;
    background-color: rgba(0,0,0,0.6); 
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    border-radius: 10px;
    border : 2px grey solid;
    animation: fadeIn 0.3s;
}

.modal-content {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    width: 100%;
    max-height: 100%;
    overflow-y: auto;
    overflow-x: hidden;
    word-wrap: break-word;
    padding-right: 20px;
    box-sizing: border-box;
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

.close-btn {
    color: #aaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
    margin-top: -10px;
}

.close-btn:hover,
.close-btn:focus {
    color: black;
    text-decoration: none;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

th, td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}

th {
    background-color: #f2f2f2;
    color: #333;
    font-weight: bold;
}

tr:nth-child(even) {
    background-color: #f9f9f9;
}

tr:hover {
    background-color: #f1f1f1;
}

h1 {
text-align : center;
}

h2 {
    text-align: left;
    color: #333;
}

h3 {
    text-align: center;
    color: #555;
    white-space: normal;
    word-wrap: break-word;
}

p {
    text-align: left;
    color: #333;
    font-size:14px;
}

strong {
    font-weight: bold;
    color: #000;
}

button {
    display: inline-block;
    padding: 10px 20px;
    margin: 10px 0;
    font-size: 16px;
    color: #fff;
    background-color: #007bff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    text-align: center;
    text-decoration: none;
}

button:hover {
    background-color: #0056b3;
}

.spinner {
    border: 16px solid #f3f3f3;
    border-top: 16px solid #3498db;
    border-radius: 50%;
    width: 120px;
    height: 120px;
    animation: spin 2s linear infinite;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 1001;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

/* Custom Scrollbar Styling */
.modal-content::-webkit-scrollbar {
    width: 8px;
}

.modal-content::-webkit-scrollbar-thumb {
    background-color: #000;
    border-radius: 10px;
}

.modal-content::-webkit-scrollbar-track {
    background-color: #f1f1f1;
}
`;
document.head.appendChild(style);
