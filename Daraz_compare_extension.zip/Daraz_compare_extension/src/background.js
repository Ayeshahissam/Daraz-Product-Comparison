const Sentiment = require('sentiment');
const sentiment = new Sentiment();

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'addProduct') {
        chrome.storage.local.get(['products'], (result) => {
            let products = result.products || [];
            if (!products.some(product => product.url === request.product.url)) {
                products.push(request.product);
                chrome.storage.local.set({ products }, () => {
                    console.log('Product added:', request.product);
                });
            } else {
                console.log('Product already added:', request.product);
            }
        });
    } else if (request.action === 'compareProducts') {
        chrome.storage.local.get(['products'], (result) => {
            let products = result.products || [];
            console.log('Products to be compared:', products);
            if (products.length >= 2) {
                try {
                    const analyzeSentiment = (reviews) => {
                        const sentiments = reviews.map(review => sentiment.analyze(review).score);
                        return sentiments;
                    };

                    const product1 = products[0];
                    const product2 = products[1];

                    const title1 = product1.title;
                    const title2 = product2.title;
                    const price1 = product1.price;
                    const price2 = product2.price;

                    const reviews1 = product1.reviews || [];
                    const reviews2 = product2.reviews || [];

                    const sentiments1 = analyzeSentiment(reviews1);
                    const sentiments2 = analyzeSentiment(reviews2);

                    const avg_sentiment1 = sentiments1.reduce((a, b) => a + b, 0) / sentiments1.length;
                    const avg_sentiment2 = sentiments2.reduce((a, b) => a + b, 0) / sentiments2.length;

                    const price1_float = parseFloat(price1.replace('Rs.', '').replace(',', ''));
                    const price2_float = parseFloat(price2.replace('Rs.', '').replace(',', ''));

                    const price_comparison = price1_float < price2_float ? "cheaper" : price1_float > price2_float ? "more expensive" : "the same price";

                    let overall_comparison;
                    if (avg_sentiment1 > avg_sentiment2) {
                        overall_comparison = "better";
                    } else if (avg_sentiment1 < avg_sentiment2) {
                        overall_comparison = "worse";
                    } else {
                        if (price1_float < price2_float) {
                            overall_comparison = "better";
                        } else if (price1_float > price2_float) {
                            overall_comparison = "worse";
                        } else {
                            overall_comparison = "equally good";
                        }
                    }

                    const comparison_result = `Product 1 is ${price_comparison} than Product 2.\nThe average sentiment score of Product 1 is ${avg_sentiment1.toFixed(2)}, while the average sentiment score of Product 2 is ${avg_sentiment2.toFixed(2)}.\nOverall, Product 1 is ${overall_comparison} compared to Product 2.`;

                    const comparison_data = {
                        "Metric": ["Sentiment Score", "Price", "Number of Reviews"],
                        "Product 1": [avg_sentiment1, price1_float, reviews1.length],
                        "Product 2": [avg_sentiment2, price2_float, reviews2.length]
                    };

                    sendResponse({ data: { comparison_result, comparison_data, title1, title2, avg_sentiment1, avg_sentiment2 } });
                } catch (error) {
                    console.error('Error comparing products:', error);
                    sendResponse({ error: `Failed to compare products. ${error.message}` });
                }
            } else {
                sendResponse({ error: 'Please add at least 2 products to compare.' });
            }
        });

        // Indicate that we will respond asynchronously
        return true;
    }
});
