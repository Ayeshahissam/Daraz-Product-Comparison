document.addEventListener('DOMContentLoaded', () => {
    const params = new URLSearchParams(window.location.search);
    try {
        const data = JSON.parse(decodeURIComponent(params.get('data') || '{}'));

        if (!data || !data.comparison_result) {
            document.getElementById('comparison-result').textContent = 'No data available for comparison.';
            return;
        }

        const { comparison_result, comparison_data, title1, title2, avg_sentiment1, avg_sentiment2 } = data;

        let comparisonHtml = `<h2>Comparison Result</h2>
                               <h3>${title1} vs ${title2}</h3>
                               <table border="1">
                                   <tr><th>Metric</th><th>Product 1</th><th>Product 2</th></tr>`;
        comparison_data.Metric.forEach((metric, index) => {
            comparisonHtml += `<tr>
                                   <td>${metric}</td>
                                   <td>${comparison_data['Product 1'][index]}</td>
                                   <td>${comparison_data['Product 2'][index]}</td>
                               </tr>`;
        });
        comparisonHtml += '</table>';
        comparisonHtml += `<p>${comparison_result.replace(/\n/g, '<br>')}</p>`;

        document.getElementById('comparison-result').innerHTML = comparisonHtml;
    } catch (e) {
        console.error('Error parsing comparison data:', e);
        document.getElementById('comparison-result').textContent = 'Failed to load comparison data.';
    }
});
