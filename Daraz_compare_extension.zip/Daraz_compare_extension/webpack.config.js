const path = require('path');

module.exports = {
  entry: './src/background.js',
  output: {
    filename: 'background.bundle.js',
    path: path.resolve(__dirname, 'dist'),
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/preset-env'],
          },
        },
      },
    ],
  },
  target: 'webworker',
  mode: 'development', // Set this to 'development' or 'production'
  devtool: 'source-map', // Change devtool to 'source-map'
  resolve: {
    fallback: {
      "fs": false,
      "path": false,
    }
  }
};
